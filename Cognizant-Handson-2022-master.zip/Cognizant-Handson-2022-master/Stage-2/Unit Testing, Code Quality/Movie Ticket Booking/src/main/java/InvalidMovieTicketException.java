public class InvalidMovieTicketException extends Exception {
	public InvalidMovieTicketException(String message) {
		super(message);
	}
}
