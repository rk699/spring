package com.cts.academy.dao;

public interface TrainerCohortMapDAO {
	void mapTrainerCohort(String trainerId, String cohortCode);
}
