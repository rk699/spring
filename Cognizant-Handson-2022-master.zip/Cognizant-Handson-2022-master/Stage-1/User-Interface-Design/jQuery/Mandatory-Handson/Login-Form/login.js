$('#signup_div').hide();
$('#signup').click(function() {
    $('#signup_div').show();
});