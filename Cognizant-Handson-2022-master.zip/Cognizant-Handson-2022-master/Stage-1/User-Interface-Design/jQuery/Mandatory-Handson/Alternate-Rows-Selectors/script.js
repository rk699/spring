$(function() {
    $("table caption").css("background-color", "lightblue");
    $("table tr:odd").css("background-color", "lightblue");
    $("table tr:even").css("background-color", "lightpink");
});