$("#div1").click(function() {
    console.log("clicked");
    $("#div2").text("You Nailed it!! Best of Luck!!");
    $("#div2").css("display", "block");
    $("#div2").addClass("highlight");
});