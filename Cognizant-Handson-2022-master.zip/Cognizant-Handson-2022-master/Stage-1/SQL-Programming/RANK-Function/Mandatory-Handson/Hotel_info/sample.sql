SELECT CONCAT(hotel_name," is a ", hotel_type, " hotel") AS hotel_info
FROM hotel_details
ORDER BY hotel_info DESC;