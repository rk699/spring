SELECT CONCAT(address,", ", city) AS address
FROM student
ORDER BY address DESC;