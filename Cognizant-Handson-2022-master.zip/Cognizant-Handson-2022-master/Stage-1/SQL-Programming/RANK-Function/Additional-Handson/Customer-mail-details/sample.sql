SELECT CONCAT(customer_id, " mail id is ", email_id) AS CUSTOMER_MAIL_INFO
FROM customers
ORDER BY 1;