CREATE TABLE owners(
    owner_id VARCHAR(10),
    owner_name VARCHAR(20),
    address VARCHAR(20),
    phone_no BIGINT,
    email_id VARCHAR(20),
    PRIMARY KEY(owner_id)
);