SELECT department_name FROM Department
WHERE department_block_number = 3
ORDER BY department_name;