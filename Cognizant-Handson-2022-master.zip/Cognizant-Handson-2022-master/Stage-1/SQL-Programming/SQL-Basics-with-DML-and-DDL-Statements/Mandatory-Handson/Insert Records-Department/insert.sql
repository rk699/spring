INSERT INTO Department
VALUES (1,'CSE', 3),
    (2,'IT',3),
    (3,'SE',3);