grep "[^#]" teknoscript.txt

# grep -v "^#" teknoscript.txt
