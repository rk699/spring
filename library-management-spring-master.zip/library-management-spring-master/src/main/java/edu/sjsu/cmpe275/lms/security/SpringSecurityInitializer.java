package edu.sjsu.cmpe275.lms.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * Created by SkandaBhargav on 11/26/16.
 */
public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}
