# InitCap

Write a program to convert the first character of each word in a sentence to uppercase.

If the first character of each word in the given sentence is already in upper case, then print "First character of each word is already in uppercase".

> Sample Input 1: 

    Enter the String:
    Work hard to get what you like

> Sample Output 1:

    Work Hard To Get What You Like

---

> Sample Input 2:

    Enter the String:
    Work Hard To Get What You Like

> Sample Output 2:

    First character of each word is already in uppercase