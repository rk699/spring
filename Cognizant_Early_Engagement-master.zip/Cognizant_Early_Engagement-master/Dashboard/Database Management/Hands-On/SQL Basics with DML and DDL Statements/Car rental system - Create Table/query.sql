create table owners
(
    owner_id VARCHAR(10) primary key,
    owner_name varchar(20),
    address varchar(20),
    phone_no bigint,
    email_id varchar(20)
);