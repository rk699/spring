# Car rental system - Create Table

Refer to the given schema.

Write a query to create the Owners table with the specified columns and constraints.

*Note: Letters in bold represents the table name*

*Note: Maintain the same sequence of column order, as specified in the question description*

![database diagram](../database_2.png)