insert into department (Department_id, Department_name, department_block_number)
values (1, "CSE", 3),
       (2, "IT", 3),
       (3, "SE", 3);