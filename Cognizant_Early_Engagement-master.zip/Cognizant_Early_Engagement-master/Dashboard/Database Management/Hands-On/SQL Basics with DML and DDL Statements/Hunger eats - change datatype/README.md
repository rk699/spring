# Hunger eats - change datatype

Refer to the given schema. Assume that the 'Customers' table has been already created.

Write a query to change the data type of the field customer_id in Customers table to int.

*Note: Letters in bold represents the attribute name*

![database diagram](database_3.png)
