alter table cars
add column car_regno varchar(10);