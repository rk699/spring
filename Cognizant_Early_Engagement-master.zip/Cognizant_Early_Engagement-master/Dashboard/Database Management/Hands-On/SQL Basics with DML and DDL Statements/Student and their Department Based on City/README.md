# Student and their Department Based on City

Write a query to display list of students name and their department name who are all from 'Coimbatore'. Sort the result based on students name  

![database diagram](../database_1.jpg)