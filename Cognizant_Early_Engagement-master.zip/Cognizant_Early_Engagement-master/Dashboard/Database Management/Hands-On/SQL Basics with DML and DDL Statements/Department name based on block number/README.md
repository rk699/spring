# Department name based on block number

Write a query to display the names of the departments in block number 3. Sort the records in ascending order.

![database diagram](../database_1.jpg)