
$(document).ready(function(){
    $("button").click(function(){
      $("div").toggleClass("box");
    });
  });