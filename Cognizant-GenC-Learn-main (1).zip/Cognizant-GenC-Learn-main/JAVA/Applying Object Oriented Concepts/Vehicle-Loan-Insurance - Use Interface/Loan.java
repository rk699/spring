
public interface Loan {
	abstract double issueLoan();

}
