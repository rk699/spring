
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle v1 = new Vehicle("351", "Honda", "Luxury", 150000.00);
		v1.issueLoan();
		v1.takeInsurance();

	}

}
