public interface Insurance {
	abstract double takeInsurance();

}
