public interface TuitionFee {
      
    // Fill the code here
     int calculateTuitionFees(String courseType, int basicFee, int noOfSemesters);

    
}