package com.cts.passportService;

public interface HeadPassportOffice {
	
	public void doPhotoVerification();
	
	public void issuePassport();

}
