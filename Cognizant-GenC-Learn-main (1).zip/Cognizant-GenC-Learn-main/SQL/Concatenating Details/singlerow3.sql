select concat(address,',',city) as Address 
from student
order by Address desc;