insert into Department values(1,'CSE',3);
insert into Department values(2,'IT',3);
insert into Department values(3,'SE',3);