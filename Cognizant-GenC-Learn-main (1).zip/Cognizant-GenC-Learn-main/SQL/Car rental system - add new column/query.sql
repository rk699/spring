alter table cars
add column Car_Regno VARCHAR(10);