create table owners(
owner_id varchar(10) primary key,
owner_name varchar(20) null,
address varchar(20) null,
phone_no bigint null,
email_id varchar(20) null);