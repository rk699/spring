alter table hotel_details
change rating hotel_rating int;