alter table customers
modify column customer_id int ;