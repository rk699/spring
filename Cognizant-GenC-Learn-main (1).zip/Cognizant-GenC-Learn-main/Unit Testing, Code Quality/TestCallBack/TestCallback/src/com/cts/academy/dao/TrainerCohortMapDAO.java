package com.cts.academy.dao;

public interface TrainerCohortMapDAO {
	public void mapTrainerCohort(String trainerId, String cohortCode);
}
